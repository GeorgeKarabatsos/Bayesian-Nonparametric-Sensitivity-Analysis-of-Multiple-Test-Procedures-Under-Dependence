# This file, named 'main.R', is originally located in the 'code' sub folder 
# of the Code_and_Data Supplements file folder (from the 'Code_and_Data.zip' file)
# for the article entitled:
# 
# "Bayesian Nonparametric Sensitivity Analysis of Multiple Test Procedures Under Dependence", 
# by author George Karabatsos (2025), 
# 
# contains a file named 'README.TXT', 
# and also contains three sub folders named 'code', 'data', and 'results'. 
# This 'Code_and_Data' Supplements file folder also contains the 
# sub folders named 'data' and 'results'.
# 
# In particular, this 'main.R' file, 
# uses (calls) the R code file 'DoFiguresTables.R' 
# (located in the 'code' sub folder of the 'Code_and_Data' Supplements file folder), 
# to read (import) the file:
# 
# 'Output_PISA_2022_USA_p-values_2025-03-01_[17h][30m][04s].csv'
# (located in the 'data' sub folder of the 'Code_and_Data' Supplements file folder),
# 
# and then to reproduce the results of:
# - Figure 1 and Figure 2 of the article;
# - the actual detailed results of the "output table" that 
# 	is briefly referred to in Section 4 of the article; 
# -	a table of numerical results of the Gibbs sampling of 
# 	the posterior distribution of the mass parameter (M) of the Dirichlet process,
# 	these results reported in Section 4.1 of the article.
# The results Figure 1, Figure 2, and the two output tables, mentioned above, 
# are respectfully, stored as files 'Figure1.pdf' and 'Figure2.pdf',
# and two comma-delimited (*.csv) files, named:

# 'Output_PISA_2022_USA_p-values_and_ppps_values_2025-04-26_<OUTPUT TIME>.csv'
# 'Output_M_Posterior(28679clusters)_<OUTPUT TIME>.csv'

# which are output into the 'results' sub folder of 
# the 'Code_and_Data' Supplements file folder.

# Users: before you do any further computations with this 'main.R' file, 
# in the R code line below, 
# you need to specify the sub folder name(s) of your working directory
# that contains the "Code_and_Data" folder, within 'file.path()',
# and then run this code line in R,
# e.g., by pointing and clicking to this command line below, 
# and clicking the R menu options: 'Edit > run line or selection':

main.path = file.path( . , . , "Code_and_Data")

# For example, on the 'C' drive on a Windows (PC) Personal Computer, one may use:
# main.path = file.path("C:", "Users" , "George Karabatsos" , "Desktop" , "Code_and_Data")

# Now, you can run the two R command lines below, 
# including the 'source()' R command line,
# to output and reproduce the results (output files) of 
# reported in Figure 1 and Figure 2 of the article, 
# the detailed results of the "output table" referred to by section 4
# of the article, and the results of the posterior distribution of the 
# mass parameter (M) of the Dirichlet process, reported in 
# Section 4.1 of the article:

setwd(file.path(main.path , "code" ))
Output1 = source("DoFiguresTables.R")

# As mentioned, all of the above results, produced by the code line above, 
# are output into the 'results' sub folder of the 'Code_and_Data' Supplements file folder,
# as output files with the following names:
# 'Figure1.pdf'
# 'Figure2.pdf'
# 'Output_PISA_2022_USA_p-values_and_ppps_values_2025-04-26_<OUTPUT TIME>.csv'
# 'Output_M_Posterior(28679clusters)_<OUTPUT TIME>.csv'
# ============================================================================================



# ============================================================================================
# *Optionally*, the 'main.R' file can also be run to use (call)
# the R code file 'p-valuesCompute.R' (located in the 'code' sub folder),
# to read (import) the following original PISA data files, named:
# 
# 'CY08MSP_STU_QQQ_USA_(selected variables).csv'
# 'CY08MSP_STU_QQQ_USA_variable_labels.txt'
# 
# and from these files, to reproduce the 28,679 p-values (hypothesis tests) 
# already contained in the above-mentioned file: 
# 
# 'Output_PISA_2022_USA_p-values_2025-03-01_[17h][30m][04s].csv'
# 
# However, computing all of these 28,679 p-values can take around 
# 20 minutes on a modern laptop computer.
# All of these computed p-values results are 
# output into a comma-delimited (*.csv) file, named:
# 
# 'Output_PISA_2022_USA_p-values_<OUTPUT TIME>.csv'
# 
# which is also stored in the 'results' sub folder of 
# the 'Code_and_Data' Supplements file folder.
# 
# Users: before you do any further computations with this 'main.R' file, 
# in the R code line below, 
# you need to specify the sub folder name(s) of your working directory
# that contains the "Code_and_Data" folder, within 'file.path()',
# and then run this code line in R,
# e.g., by pointing and clicking to this command line below, 
# and clicking the R menu options: 'Edit > run line or selection':

main.path = file.path( . , . , "Code_and_Data")

# For example, on the 'C' drive on a Windows (PC) Personal Computer, one may use:
# main.path = file.path("C:", "Users" , "George Karabatsos" , "Desktop" , "Code_and_Data")

# Now, you can run the three R command lines below, 
# including the 'source()' R command line,
# to output and reproduce the results (output file) of 
# (these p-values are the basis of all the numerical results 
# reported in Figure 1, Figure 2, and Section 4 and Section 4.1 of the article):
# (Below, to ensure the handling of this expensive computation,
# we are setting mem.maxVSize() to Infinity (Inf) 
# to set the maximum possible value for the vector heap 
# on the user's computing platform (e.g., Windows, or MacBook, etc.).
# Otherwise, common Parallel or cloud computing resources can also be used).

mem.maxVSize(vsize = Inf)
setwd(file.path(main.path , "code" ))
Output2 = source("p-valuesCompute.R")

# Again, as I mentioned above, the code line above will take a while to compute, 
#  e.g., around 20 minutes to compute on a modern laptop computer.

# As mentioned, all of the above results, produced by the code line above, 
# are output into the 'results' sub folder of the 'Code_and_Data' Supplements file folder,
# as a comma-delimited (*.csv) output file, named:
#
# 'Output_PISA_2022_USA_p-values_<OUTPUT TIME>.csv'
#
# It can be verified that the p-values of the above output file
# matches the p-values of the previous file:
# 
# 'Output_PISA_2022_USA_p-values_2025-03-01_[17h][30m][04s].csv'
#
# used to compute Figure1.pdf, Figure2.pdf, and the results 
# in the two other comma delimited (*.csv) output files, mentioned further above.
# ============================================================================================