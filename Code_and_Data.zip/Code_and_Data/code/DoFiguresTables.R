#=======================================================================================================================
# Import the p-values from corresponding m = 28,679 null hypothesis tests performed on the PISA dataset,
# in order to analyze and plot for Figures 1 and 2, produced by the R code lines further below.
#=======================================================================================================================
# Import the p-values (and related results and information on hypothesis tests):
main.path = "C:\\Users\\George Karabatsos\\Desktop\\Code_and_Data"

setwd(file.path(main.path , "data"))
Results = 	read.csv('Output_PISA_2022_USA_p-values_2025-03-01_[17h][30m][04s].csv')
# fix(Results)  # view results in a spreadsheet (close spreadsheet after you are done viewing this)  
# colnames(Results)# This R code line outputs the following variable names:
# "V1"         "V2"         "ptau_OR_BMtest_p.hat" "p.value.2tailed"     
# "statistic"  "variance"   "n.pairwiseDel"        "V1_label"       "V2_label"
#
# extract 2-tailed p-values, which for the above dataset, are already sorted in increasing order:
p =	Results[ , colnames(Results) == "p.value.2tailed"] 
#
m =	length(p) 	# Number of hypothesis tests.
alpha =	0.05	# Chosen error control
p.sort = sort(p)# sorted p-values
#=======================================================================================================================


#=======================================================================================================================
# Export histogram plot (Figure 1) of p-values and significance thresholds (R), for various MTPs.
#=======================================================================================================================
setwd(file.path(main.path , "results"))
# Generate random weighted Bonferroni MTP values:
set.seed(123) 	# For reproducibility of simulations. This sets the state of the random number generator.
N = 1000 		# Number of Monte Carlo samples
#
# Calculate significance thresholds (Delta) for various MTPs:
Delta.Bonf = rep(alpha / m , m)
Delta.Sidak	= rep(1 - (1 - alpha) ^ (1 / m) , m)
r.wBonf = matrix(rgamma(m * N , shape = 1 , rate = 1) , m , N)
r.wBonf = r.wBonf / matrix(colSums(r.wBonf) , nrow = 1)[rep(1 , m) , ] # colSums(r.wBonf)
r.Delta.wBonf =	r.wBonf
Delta.Holm = alpha / (m : 1)
Delta.BH = alpha * (1 : m) / m
gamma_m = sum(1 / (1 : m)) # Blanchard & Roquain's (2008, p.976) notation.
Delta.BY = alpha * ((1 : m) * (gamma_m ^ (- 1) )) /	m
#
# Count number (R) of significant p-values (null rejections) for each MTP.
R.Bonf = sum(p.sort <= Delta.Bonf)
R.Sidak	= sum(p.sort <= Delta.Sidak)
R.Holm = sum(p.sort <= Delta.Holm)
R.r.wBonf = colSums((matrix(p.sort , ncol = 1)[ , rep(1 , N)]) <= r.Delta.wBonf)
R.wBonf	= c( mean(R.r.wBonf) , sd(R.r.wBonf) )# Mean and standard deviation of Nsig.
R.BY = sum( p.sort <= Delta.BY )
R.BH = sum( p.sort <= Delta.BH )
#-----------------------------------------------------------------------------------------------------------------------
# Now, plot histogram and export it as the Figure 1 file:
#-----------------------------------------------------------------------------------------------------------------------
# Open pdf file of Figure 1 (to export into a file, later below):
pdf("Figure1.pdf" , useDingbats = FALSE)
# Construct the histogram in Figure 1:
hist(p , main = "Histogram of p-values, and number of discoveries (R) by MTP", 
		xlab = 'p-value' , ylab = 'Frequency' , cex.lab = 1 , cex.axis = 1 ,
		breaks = seq(from = 0 , to = 1 , by = .05))
abline(h = R.BH , col = 'red' , lwd = 2)
abline(h = R.BY , col = 'orange' , lwd = 2)
abline(h = R.wBonf[1], col = 'lightblue' , lwd = 2)
abline(h = R.wBonf[1] - 2 * R.wBonf[2] , col = 'lightblue' , lwd = 2 , lty = 3)
abline(h = R.wBonf[1] + 2 * R.wBonf[2] , col = 'lightblue' , lwd = 2 , lty = 3)
abline(h = R.Holm , col = 'forestgreen', lwd = 2)
abline(h = R.Sidak , col = 'grey' , lwd = 2)
abline(h = R.Bonf , col = 'blue' , lwd = 2)
legend("right" ,  xpd = TRUE ,
	legend = c(	paste('Benjamini-Hochberg (1995) MTP' , ' [' , R.BH , ' discoveries]' , sep = '') ,
				paste('Benjamini-Yekutieli (2001) MTP' , ' [' , R.BY , ' discoveries]' , sep = '') ,
				paste('Weighted Bonferroni MTP' , ' [M=' , round(R.wBonf[1] , 1) , 
					  ' (SD=' , round(R.wBonf[2] , 1) , ')' , ' discoveries]' , sep = '') ,
				paste('Holm (1979) MTP' , ' ['  , R.Holm , ' discoveries]' , sep = '') ,
				paste('Šidák (1967) MTP' , ' [' , R.Sidak ,' discoveries]' , sep = '') ,
				paste('Bonferroni (1936) MTP' ,	' [' , R.Bonf , ' discoveries]' , sep = '')) ,
  	fill = c(	'red' ,			# Benjamini-Hochberg (1995) Step-Up MTP
				'orange' ,		# Benjamini-Yekutieli (2001) Step-Up MTP
				'lightblue' ,	# Weighted Bonferroni MTP
				'forestgreen' , # Holm Step-Down MTP
				'grey' ,		# Šidák (1967) MTP
				'blue'	) , 	# Bonferroni MTP
	bty = "n" , cex = 1.0)# Type colors() in R console for the available colors.
dev.off() # Close Figure 1 in the current working R session.
#=======================================================================================================================


#=======================================================================================================================
# Export a two-panel plot (Figure 2), where:
# the top panel is a histogram of p-values and significance thresholds (R), for various MTPs,
# including the MTP based on the Dirichlet process;
# and the bottom panel gives the 
# DP predictive probability of significance,
# for each of the sorted p-values less than or equal to alpha = 0.05.
#=======================================================================================================================
# Open pdf file of Figure 2 (to export into a file, later below):
pdf("Figure2.pdf" , useDingbats = FALSE)
#
# R code below runs the DP-MTP Sensitivity analysis method of the article.
#-----------------------------------------------------------------------------------------------------------------------
# INPUTS.  Enter user inputs:
#-----------------------------------------------------------------------------------------------------------------------
# Enter your p-values in the code line, below:
# p = runif(11, min = 0, max = 0.03) # Example p-values (random)
#
# Enter alpha in the code line, below (e.g., 0.05 or 0.01, etc.):
alpha = 0.05 # alpha = Level of Type I error rate control.
#
# Enter the number of Monte Carlo samples in the code line below:
N = 1000 # N = Number of Monte Carlo samples
#-----------------------------------------------------------------------------------------------------------------------
# Organize the p-values:
#-----------------------------------------------------------------------------------------------------------------------
m = length(p) # m = Number of hypothesis tests (p-values).
p.sort. = sort(p , index.return = TRUE)
p.sort = p.sort.$x # the m p-values sorted in increasing order.
p.sortI = p.sort.$ix # ordering index vector for sorted p-values.
P.sort = matrix(p.sort , nrow = 1)[rep(1 , N) , ] # N by m matrix.
#-----------------------------------------------------------------------------------------------------------------------
# Draw N samples of nu and corresponding thresholds (Deltas):
#-----------------------------------------------------------------------------------------------------------------------
set.seed(123) # For reproducibility of simulations. This sets the state of the random number generator.
# Draw N samples of M from the exponential(1) hyperprior distribution:
M = matrix(rexp(N , rate = 1) , nrow = 1)[rep(1 , m) , ] # m by N matrix.
# Draw N corresponding samples of nu from DP(M, nu0) prior distribution:
nu0 = M * ( (matrix(rep(1 : m , N) , m , N) * sum(1 / (1 : m))) ** (- 1) )
r.nu = matrix(rgamma(m * N , shape = nu0 , rate = 1) , m , N)
r.nu = r.nu / matrix(colSums(r.nu) , nrow = 1)[rep(1 , m) , ]
# Get N corresponding random samples of beta and Delta:
r = matrix(rep(1 : m , N) , m , N)
r.beta = apply(r * r.nu , 2 , cumsum)
r.Delta = t(alpha * r.beta / m)
# Get N corresponding step-up decisions on the R smallest p-values:
r.R = matrix( max.col( cbind(0, P.sort) <= cbind(0, r.Delta) , "last") - 1 , ncol = 1)[ , rep( 1 , m)]
#
#-----------------------------------------------------------------------------------------------------------------------
# OUTPUTS
#-----------------------------------------------------------------------------------------------------------------------
PrSig.p = colMeans(matrix(1 : m , nrow = 1)[rep(1 , N) , ] <= r.R , na.rm = T)
# PrSig.p # DP predictive probability of significance,for each p-value.
R.DPsamples = r.R[ , 1]# Vector of DP prior predictive samples of R
#-----------------------------------------------------------------------------------------------------------------------

# DP prior predictive number of discoveries (significant p-values):
E.R.DP = sum(PrSig.p) # This equals mean(R.DPsamples, na.rm = T)
SD.R.DP	= sd(R.DPsamples , na.rm = T) # Mean and standard deviation of Nsig.

par(mfrow = c(2 , 1)) # Set up Figure 2 as a matrix plot with two rows and one column

# Plot the  MTPs and the sorted p-values (using nDP of N realizations of the DP):
# SubPlot #1:
# Plot the Histogram of DP prior predictive of R, and number of discoveries (R) by MTP:
hist(R.DPsamples , main = "Histogram of DP prior predictive of R, and discoveries (R) by MTP", 
			xlab = 'Number of Discoveries (R)' , ylab = 'Frequency',
			xlim = c(20000 , 27000) , cex.lab = 1 , cex.axis = 1 , breaks = 'FD')
abline(v = R.BH , col = 'red' , lwd = 2)
abline(v = R.BY , col = 'orange' , lwd = 2)
abline(v = E.R.DP , col = 'darkviolet' , lwd = 2)
abline(v = E.R.DP - 2 * SD.R.DP , col = 'darkviolet' , lwd = 2 , lty = 3)
abline(v = E.R.DP + 2 * SD.R.DP , col = 'darkviolet' , lwd = 2 , lty = 3)
abline(v = R.wBonf[1] , col = 'lightblue' , lwd = 2)
abline(v = R.wBonf[1] - 2 * R.wBonf[2] , col = 'lightblue' , lwd = 2 , lty = 3)
abline(v = R.wBonf[1] + 2 * R.wBonf[2] , col = 'lightblue' , lwd = 2 , lty = 3)
abline(v = R.Holm , col = 'forestgreen' , lwd = 2)
abline(v = R.Sidak , col = 'grey' , lwd = 2)
abline(v = R.Bonf , col = 'blue' , lwd = 2)
legend('topleft' , xpd = FALSE ,
	legend 	= 	c(	paste('Benjamini-Hochberg'  , ' [' , R.BH , ']' , sep = '') ,
					paste('Benjamini-Yekutieli' , ' [' , R.BY , ']' , sep = '') ,
					paste('DP' , ' [M=' , round(E.R.DP , 1) , 
						  ' (SD=' , round(SD.R.DP , 1) , ')' , ']' , sep = '') ,
					paste('W.Bonf' , ' [M=' , round(R.wBonf[1] , 1) , 
						  ' (SD=' , round(R.wBonf[2] , 1) , ')' , ']' , sep = '') ,
					paste('Holm' , ' [' , R.Holm , ']' , sep = '') ,
					paste('Šidák' , ' [' , R.Sidak ,']' , sep = '') ,
					paste('Bonferroni' , ' [' , R.Bonf , ']' , sep = '')) ,
  	fill 	= 	c(	'red' ,			# Benjamini-Hochberg (1995) Step-Up MTP
					'orange' ,		# Benjamini-Yekutieli (2001) Step-Up MTP
					'darkviolet' ,	# Dirichlet Process MTP
					'lightblue' ,	# Weighted Bonferroni MTP
					'forestgreen' ,	# Holm Step-Down MTP
					'grey' ,		# Šidák (1967) MTP
					'blue' ) , 		# Bonferroni MTP
	bty = "o" , cex = 1 , bg = "white")# Type colors() in R console for the available colors.
#
# SubPlot #2: sorted p-values and prior predictive probability of discovery (significance),
# for each of the m p-values, based on the Dirichlet process MTP.
plot(p.sort[p.sort <= 0.05] , PrSig.p[p.sort <= 0.05] , 
main = "DP prior predictive probability of discovery, for each p-value",
xlab = 'Sorted p-values', ylab = 'Prior probability of discovery', cex.lab = 1, cex.axis = 1)
dev.off() # Close the figure file
#-----------------------------------------------------------------------------------------------------------------------
# Export table output of sorted p-values 
# and prior predictive probability of significance (ppps),
# for each of the m p-values, based on the Dirichlet process MTP.
# This output table also shows the variable labels for each p-value (hypothesis test).
# This is the "output table" referred to by Section 4 of the article.
#-----------------------------------------------------------------------------------------------------------------------
outTable = as.matrix(cbind(p.sort , PrSig.p , Results[p.sortI , c(1 , 2 , 8 , 9)]))
Time = paste(Sys.Date() , format(Sys.time() , "[%Hh][%Mm][%Ss]"), sep = '_')
setwd(file.path(main.path , "results"))
nameOutput = paste('Output_PISA-2022-USA_p-values_and_ppps_values_' , Time , '.csv', sep = '')
write.csv(outTable , nameOutput , row.names = FALSE)
#=======================================================================================================================



#=======================================================================================================================
# Run a Gibbs sampler for estimating the posterior distribution of M 
# (The following code lines produce results reported in Section 4.1 of the article)
#=======================================================================================================================
# From Section 6 of Escobar & West (1995, JASA),  based on a gamma prior for M, 
# this prior allowing the posterior of M to be characterized as a mixture of 
# two gamma distributions, with mixture weights determined by a parameter (eta)
# having a beta conditional posterior distribution:
# [specifically, they used results in Definition 6 and Proposition 3 in Antoniak (1974),
# which characterize the distribution of the number of clusters under a Dirichlet process.
# [Korwar & Hollander (1973,p.707) state that they use an alternative to these results of 
# Antoniak (1974), by using a more "fine structure", by characterizing the distribution 
# of the number of distinct observations (i.e., clusters) 
# by a generalized binomial distribution with n varying probabilities.]
#
# colnames(Results)# This outputs:
# "V1"         "V2"         "ptau_OR_BMtest_p.hat" "p.value.2tailed"     
# "statistic"  "variance"   "n.pairwiseDel"        "V1_label"       "V2_label"
#
# extract 2-tailed p-values, which for the above dataset, are already sorted in increasing order:
p =	Results[ , colnames(Results) == "p.value.2tailed"] 
test.stats = Results[ , colnames(Results) == "statistic"] 
# Using test.stats instead of p-values to count the number of distict p-values, 
# since p-values are more subject to numerical underflow.
#
set.seed(123)# For reproducibility of simulations. This sets the state of the random number generator.
nMCMC = 20000 # Number of MCMC posterior samples
for (s in 1 : nMCMC) {
	if (s == 1) {# Set the starting values of MCMC algorithm:
		a =	1	# Based on Exponential(1) prior for M
		b =	1	# Gamma scale parameter, based on Exponential(1) prior for M
		m = length(p)
		k = length(unique(test.stats)) # Number of distinct p-values (i.e. # clusters)
		M = k / log(m) # Starting value of DP precision parameter M
   		# (starting value is the large-sample MLE of M from Korwar & Hollander(1973) ) 
		M.samples =	matrix(NA , nrow = nMCMC , ncol = 1)
		Lm = sum(1 / (1 : m)) # from Fithian & Lei (2022, p.3093)
		v0 = ((1 : m) * Lm) ^ (- 1)# from Fithian & Lei (2022, p.3094) and Blanchard & Roquain (2008,p.976)
		Var.v.samples =	matrix(NA , nrow = nMCMC , ncol = 1)
	}
	eta = rbeta(1 , M + 1 , m)
	odds = (a + k - 1) / (m * (b - log(eta))) 
	pi.eta = odds / (1 + odds)# OK: odds equals pi.eta/(1 - pi.eta)
	I =	as.numeric( runif(1) > pi.eta )
	M = rgamma(1 , shape = a + k - I , rate = b - log(eta))
	M.samples[s] = M
	Var.v.samples[s] = max( (v0 * (1 - v0)) / (M + 1) )
}
nBurnin = 10000;	
burnin = (nMCMC - (nBurnin) + 1) : nMCMC 

# Summarize and graph from the posterior distribution 
# of the DP precision parameter M and associated quantities: 
# Histogram and 5-number summaries for DP precision (M) posterior 
# and the corresponding DP prior expected number of clusters:
# par(mfrow = c(1, 2))
# hist(M.samples[burnin]); hist(Enclus.samples[burnin])
posteriorSummary = cbind( cbind(mean(M.samples[burnin]) , sd(M.samples[burnin])) ,
								rbind(quantile(M.samples[burnin] , probs = c(0 , .25 , .5 , .75 , 1))) )
colnames(posteriorSummary)[c(1 , 2)	] = c("Mean" , "SD")
rownames(posteriorSummary)[c(1)	] =	c("M")
posteriorSummary = 	rbind(	posteriorSummary ,
								cbind(
								cbind(mean(Var.v.samples[burnin]) , sd(Var.v.samples[burnin])) ,
								rbind(quantile(Var.v.samples[burnin] , probs = c(0 , .25 , .5 , .75 , 1))) ) )
rownames(posteriorSummary)[c(2)	] =	c("DP Var v")
#
# Generate the output of the posterior results:
Time = paste(Sys.Date() , format(Sys.time() , "[%Hh][%Mm][%Ss]"), sep = '_')
setwd(file.path(main.path , "results"))
nameOutput = paste('Output_M_Posterior(' , k, 'clusters)_', Time , '.csv', sep = '')
write.csv(round(posteriorSummary , 5) , nameOutput , row.names = TRUE)
setwd(main.path)
#
# OUTPUT:
# > k # Observed number of clusters.
# [1] 28679
# > round(posteriorSummary, 5)
#                 Mean       SD          0%         25%         50%         75%        100%
# M        13364.72945 95.57727 12969.02144 13299.80261 13364.94500 13428.70743 13725.30678
# DP Var v     0.00001  0.00000     0.00001     0.00001     0.00001     0.00001     0.00001
#=======================================================================================================================