#=======================================================================================================================
# Import PIRLS 2022 USA student questionnaire dataset on selected variables, and dataset of variable labels.
#=======================================================================================================================
# Import the PISA 2022 U.S. student questionnaire dataset (x):
setwd(file.path(main.path , "data"))
x0 = read.table("CY08MSP_STU_QQQ_USA_(selected variables).csv" , header = TRUE , sep = ',')# fix(importedData)
x =	x0[ , 3 : (ncol(x0) - 2) ]# Set the dataset (x) of variables.
K =	ncol(x) # Number of variables for analysis.
n =	nrow(x) # Number of data points in dataset
# observation weights for each of the data points (respectively):
w =	matrix( x0[ , colnames(x0) == 'W_FSTUWT' ] , ncol = 1) 
n_w	= sum(w)  # Effective sample size based on sum of weights.
#
# Import and assign the variables' names and labels:
varNames = colnames(x) # Variable names
Labels = read.table("CY08MSP_STU_QQQ_USA_variable_labels.txt" , header = TRUE , sep = "\t" , quote = "")#  fix(Labels)
for (j in 1 : K) {if (j == 1){ varLabels =  matrix(0 , nrow = K , ncol = 1) }
	varLabels[j] = Labels[which(varNames[j] == Labels[ , 1]) , 3]  }
colnames(w) = 'W_FSTUWT'
#=======================================================================================================================


#=======================================================================================================================
# Calculate Brunner-Munzel tests, comparing female students and male students,
# on each of all the other variables in the data set (x)
#=======================================================================================================================
# Extract gender data:
group =	x[ , varNames == 'ST004D01T'] 
# gender is coded: 1 = Female, 2 = Male, NA = Missing)

colInd = which(varNames != 'ST004D01T')
nBMtests = length(colInd)

Out.BM = matrix( NA , nBMtests , 9)
colnames(Out.BM) =	c( 'V1' , 'V2' , 'ptau_OR_BMtest_p.hat' , 'p-value.2tailed' ,
 							'statistic' , 'variance' , 'n' , 'V1_label' , 'V2_label' )

# The weighted.rank() function, defined below, 
# was taken from the 'cNORM' R package:
# See:  https://www.rdocumentation.org/packages/cNORM/versions/2.0.2/topics/weighted.rank
# Arguments (i.e., the weighted.rank() function Inputs)
# x			A numerical vector
# weights	A numerical vector with weights; should have the same length as x
#
# Value (i.e., the weighted.rank() function Output)
# the weighted ranks
Weighted.Rank = function(x , weights = NULL){
	if (is.null(weights)) {return(rank(x))}
    else {	fact <- 1e+06
        	w <- round((weights * fact), digits = 0)
        	average.rank <- rep(x = 1 , times = length(x))
        	u <- unique(x)
        	for (i in 1 : length(u)) {
           		average.rank[which(x == u[i])] <- (sum(w[x < u[i]]) + fact + sum(w[x <= u[i]])) / 2	}
        	return(average.rank/sum(w) * length(x))	  }		}
# NOTE: It can be verified that, 
# for any dataset where each observation in group 1 has weight w_1 = 1, 
# and that each observation in group 2 has weight w_2 = 1, 
# the R code below for computing the Brunner-Munzel (BM) test statistics, 
# coincides with the test statistics reported by the 'brunnermunzel' R package.

#-----------------------------------------------------------------------------------------------------------------------
# Run the Brunner-Munzel (BM) tests in a loop:
#-----------------------------------------------------------------------------------------------------------------------
for (i in 1 : nBMtests) {
	x_1 = x[ , colInd[i]]
	x_1 = x_1[group == 1] 
	miss1 = is.na(x_1)
	x_1 = x_1[!miss1] # Female outcomes (observed)
	w_1 = w[group == 1]
	w_1 = w_1[!miss1]
	#
	x_2 = x[ , colInd[i]]
	x_2	= x_2[group == 2]
	miss2 = is.na(x_2)
	x_2	= x_2[!miss2] # Female outcomes (observed)
	w_2	= w[group == 2]
	w_2	= w_2[!miss2]
	#
	n_1.w = sum(w_1)	# Group 1 sample size (weighted).
	n_2.w = sum(w_2)	# Group 2 sample size (weighted).
	N.w = n_1.w + n_2.w	# Grand total sample size (weighted).
	#
	x_1.unique = sort(unique(x_1))
	x_1.Nunique = length(x_1.unique)
	dataFrame = data.frame( w_val = w_1 , x_val = x_1 ) 
	w_1 = aggregate(dataFrame$w_val , list(dataFrame$x_val) , FUN = sum) 
	w_1 = w_1[ , 2]
	x_2.unique = sort(unique(x_2))
	x_2.Nunique = length(x_2.unique)
	dataFrame = data.frame( w_val = w_2 , x_val = x_2 ) 
	w_2 = aggregate(dataFrame$w_val , list(dataFrame$x_val) , FUN = sum) 
	w_2 = w_2[ , 2]
	group.w = ifelse( 1 : (x_1.Nunique + x_2.Nunique) <= x_1.Nunique , 1 , 2 )
	#
	R_ik.w = (N.w / (x_1.Nunique + x_2.Nunique)) * Weighted.Rank(c(x_1.unique , x_2.unique) , weights = c(w_1 , w_2))
	R1_ik.w = (n_1.w / x_1.Nunique) * Weighted.Rank(x_1.unique , weights = w_1)
	R2_ik.w = (n_2.w / x_2.Nunique) * Weighted.Rank(x_2.unique , weights = w_2)
	#
	Rbar_1.w = weighted.mean(R_ik.w[group.w == 1] , w_1) # = sum( (w_1 / sum(w_1)) * R_ik[group.w == 1])
	Rbar_2.w = weighted.mean(R_ik.w[group.w == 2] , w_2) # = sum( (w_2 / sum(w_2)) * R_ik[group.w == 2])
	#
	Ssq_1.w = sum( (w_1 / (sum(w_1) - 1)) * (R_ik.w[group.w == 1] - R1_ik.w - Rbar_1.w + ((n_1.w + 1) / 2)) ^ 2 )
	Ssq_2.w = sum( (w_2 / (sum(w_2) - 1)) * (R_ik.w[group.w == 2] - R2_ik.w - Rbar_2.w + ((n_2.w + 1) / 2)) ^ 2 )
	# Computing Ssq_1.w and Ssq_2.w follows ideas of weighted mean and variance, in:
	# https://stackoverflow.com/questions/10049402/calculating-weighted-mean-and-standard-deviation
	#
	sigsqhat_N.w = (N.w * Ssq_1.w) / (n_1.w * (N.w - n_1.w)^2) + (N.w * Ssq_2.w) / (n_2.w * (N.w - n_2.w) ^2 )
	Vsq_N.w = N.w * ((Ssq_1.w / n_2.w) + (Ssq_2.w / n_1.w))
	# ------------------------------------------------------------------------------------------------------------------
	# Brunner–Munzel test statistic:
	# ------------------------------------------------------------------------------------------------------------------
	T_N.w = ((Rbar_2.w - Rbar_1.w) / sqrt(Vsq_N.w)) * sqrt((n_1.w * n_2.w) / N.w)# weighted
	df.w = ((Ssq_1.w / (N.w - n_1.w) + Ssq_2.w / (N.w - n_2.w)) ^ 2) / 
	        (((Ssq_1.w / (N.w - n_1.w)) ^ 2) / (n_1.w - 1) + ((Ssq_2.w / (N.w - n_2.w)) ^ 2) / (n_2.w - 1))
	pvalue.2tail.w = 2 * pt( - abs(T_N.w) , df = df.w)
	# ------------------------------------------------------------------------------------------------------------------
	# Weighted p.hat (estimate of stochastic superiority or relative effect):
	# ------------------------------------------------------------------------------------------------------------------
	w_1.w_2	= outer(w_1 , w_2 , '*')
	p.hat.w	= (sum(w_1.w_2 * outer(x_1.unique , x_2.unique , '<')) 
	        + (1 / 2) * sum(w_1.w_2 * outer(x_1.unique , x_2.unique , '=='))) / (n_1.w * n_2.w)
	# ------------------------------------------------------------------------------------------------------------------
	# Update output table for the Brunner–Munzel test:
	# ------------------------------------------------------------------------------------------------------------------
	Out.BM[i , ] = c('ST004D01T' , varNames[colInd[i]] ,
					 p.hat.w , pvalue.2tail.w , T_N.w , Vsq_N.w , N.w , 
					 paste('BM test of ' , 'n_1 = ' , n_1.w , ' females' , 
					 ' versus ' , 'n_2 = ' , n_2.w , ' males.' , sep = '') ,
					 varLabels[colInd[i]])
	# ------------------------------------------------------------------------------------------------------------------
	print(paste('Completed Brunner-Munzel test #' , i , 'out of' , nBMtests , 'total tests.') )
	flush.console()
	# ------------------------------------------------------------------------------------------------------------------
}
#=======================================================================================================================



#=======================================================================================================================
# Calculate K x K partial Kendall tau-b correlation matrix (ptau_b),
# and p-values from corresponding null hypothesis tests. 
#=======================================================================================================================
print('Now computing all the partial Kendall tau-b correlations and p-values.');
flush.console()

# Construct K x K matrix of sign statistics S.w, based on the observation weights (w):
pairs1n	= combn(1 : n , 2) # all (n*(n-1))/2 distinct pairs from integers 1:n.
h = pairs1n[1 , ] # indices h < i of the (n*(n-1))/2 distinct pairs
i = pairs1n[2 , ] # indices h < i of the (n*(n-1))/2 distinct pairs
S_K = sign(x[i , ] - x[h , ]) # (n*(n-1))/2 pairwise comparisons, for each variable X_j, for j=1,...,K.
S_K[is.na(S_K)]	= 0 # Zero-out missing responses. Same as pairwise deletion of missing data.
w_i.w_h	= w[i] * w[h]
S_w = sum(w_i.w_h) * cov.wt(S_K , wt = w_i.w_h , center = F , method = "ML")$cov
dimnames(S_w) = list( varNames , varNames ) #  fix(S_w)
#
# Kendall's tau-a (is a covariance matrix):
tau_a.w = (2 * S_w) / (n_w * (n_w - 1))	#  fix(tau_a)
# Compute the partial Kendall tau correlation matrix from tau_a:
invC = solve(tau_a.w);
D.invC = diag(sqrt(1 / diag(invC)))
ptau = -(D.invC %*% invC %*% D.invC); diag(ptau) = 1;
# NOTES:
# library('ppcor')
# 'ppcor' R package via pcor() computes the partial correlation matrix as follows:
# pcor2 <- -cov2cor(solve(tau_a.w)); diag(pcor2) <- 1
# pcor2 equals ptau above.
# Also, the same value of ptau can be obtained by 
# using solve(S_w) instead of solve(tau_a.w), and then computing:
# invC = solve(tau_a.w);   D.invC = diag(sqrt(1 / diag(invC)))
# ptau = -(D.invC %*% invC %*% D.invC); diag(ptau) = 1;
#
# Compute KxK matrix of sample sizes (sum of obs. weights)
# after pairwise deletion of missing data:
W_K = matrix(w , ncol = 1)[ , rep(1 , K)]
W_K[is.na(x)] = 0
n_w.pairDel = t(sqrt(W_K)) %*% sqrt(W_K)
dimnames(n_w.pairDel) = list(varNames , varNames) #  fix(n_w.pairDel)
#-----------------------------------------------------------------------------------------------------------------------
# Compute partial Kendall's tau-b test statistics of null hypothesis 
# of pairwise partial correlation of zero, for each element of 
# the K x K partial Kendall tau-b correlation matrix.
#-----------------------------------------------------------------------------------------------------------------------
g = K - 2 # Number of variables conditioning on, for each pairwise partial Kendall tau correlation
# Sampling variance (sigma2) of the test statistic under conditional independence:
sigma2 = (2 * (2 * (n_w - g) + 5)) / (9 * (n_w - g) * (n_w - 1 - g))
statistic = ptau / sqrt(sigma2)
diag(statistic) = 0
p.value.2tail = 2 * pnorm(-abs(statistic))
diag(p.value.2tail) = 1
# NOTE:  library('ppcor')
# 'ppcor' R package via pcor() computes the test statistic and 2-tailed p-value as above.
#-----------------------------------------------------------------------------------------------------------------------
# Export all the results in a table, sorted by increasing order of the p-values.
#-----------------------------------------------------------------------------------------------------------------------
indCol = t(matrix(rep(1 : K , K) , ncol = K))
indRow = t(indCol)
indPairs = cbind(indCol[lower.tri(indCol , diag = FALSE)] , indRow[lower.tri(indRow , diag = FALSE)])
Out.ptau = cbind( 	varNames[indPairs[ , 1]] , varNames[indPairs[ , 2]] , 
					ptau[indPairs] , p.value.2tail[indPairs] , 
					statistic[indPairs] , rep(sigma2 , K * (K - 1) / 2) ,
					n_w.pairDel[indPairs] ,
					varLabels[indPairs[ , 1]] , varLabels[indPairs[ , 2]])
Out = rbind( Out.BM , Out.ptau)
colnames(Out) =	c(	'V1' , 'V2' , 'ptau_OR_BMtest_p.hat' , 'p-value.2tailed' ,
 					'statistic' , 'variance' , 'n.pairwiseDel' , 'V1_label' , 'V2_label')
Out = Out[order( as.numeric(Out[ , 4]) ) , ]# Sort output table by increasing p-values.

# Export the output table into a file (exported into the same directory as the imported data file):
Time = paste(Sys.Date (), format(Sys.time() , "[%Hh][%Mm][%Ss]"), sep = '_')
setwd(file.path(main.path , "results"))
nameOutput = paste('Output_PISA-2022-USA_p-values_' , Time , '.csv' , sep = '')
write.csv(Out ,	nameOutput , row.names = FALSE)
setwd(main.path)
#=======================================================================================================================